# Hardware_Store_PROJ

#super user <br>
#username: ADMIN <br>
#password: ADMIN <br>
#email: inbox@olehkravets.com <br>
