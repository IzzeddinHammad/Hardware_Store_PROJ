# Hardware_Store_PROJ

#super user <br>
#username: XXX <br>
#password: 123 <br>
#email: XXX@tud.ie <br>
