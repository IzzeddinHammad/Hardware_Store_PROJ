def countries():
    return [
        {"country": "United States", "tax_rate": "7"},
        {"country": "Ukraine", "tax_rate": "22"},
    ]
