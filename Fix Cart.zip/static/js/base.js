console.log("JavaScript Loaded Successfully!");
